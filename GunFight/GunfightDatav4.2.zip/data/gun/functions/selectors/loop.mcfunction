execute as @a[tag=!Red] at @s if block ~ ~-1 ~ minecraft:stripped_mangrove_log if block ~ ~-2 ~ minecraft:stripped_mangrove_wood run function gun:selectors/joinred
execute as @a[tag=!Blue] at @s if block ~ ~-1 ~ minecraft:stripped_warped_stem if block ~ ~-2 ~ minecraft:stripped_warped_hyphae run function gun:selectors/joinblue
execute as @a[tag=!medic] at @s if block ~ ~-1 ~ pink_stained_glass if block ~ ~-2 ~ pearlescent_froglight if block ~ ~-3 ~ target run function gun:selectors/medic
execute as @a[tag=!snipe] at @s if block ~ ~-1 ~ green_stained_glass if block ~ ~-2 ~ verdant_froglight if block ~ ~-3 ~ target run function gun:selectors/snipe
execute as @a[tag=!fal] at @s if block ~ ~-1 ~ orange_stained_glass if block ~ ~-2 ~ ochre_froglight if block ~ ~-3 ~ target run function gun:selectors/fal
execute as @a[tag=!smg] at @s if block ~ ~-1 ~ blue_stained_glass if block ~ ~-2 ~ sea_lantern if block ~ ~-3 ~ target run function gun:selectors/smg
execute as @a[tag=!rpk] at @s if block ~ ~-1 ~ red_stained_glass if block ~ ~-2 ~ shroomlight if block ~ ~-3 ~ target run function gun:selectors/rpk
execute as @a[tag=!marksman] at @s if block ~ ~-1 ~ blue_stained_glass if block ~ ~-2 ~ sea_lantern if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/marksman
execute as @a[tag=!breacher] at @s if block ~ ~-1 ~ orange_stained_glass if block ~ ~-2 ~ honeycomb_block if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/breacher
execute as @a[tag=!smg2] at @s if block ~ ~-1 ~ light_blue_stained_glass if block ~ ~-2 ~ prismarine if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/smg2
execute as @a[tag=!assault] at @s if block ~ ~-1 ~ red_stained_glass if block ~ ~-2 ~ shroomlight if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/assault
execute as @a[tag=!sniper] at @s if block ~ ~-1 ~ purple_stained_glass if block ~ ~-2 ~ pearlescent_froglight if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/sniper
execute as @a[tag=!ranger] at @s if block ~ ~-1 ~ lime_stained_glass if block ~ ~-2 ~ verdant_froglight if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/ranger
execute as @a[tag=!burst] at @s if block ~ ~-1 ~ yellow_stained_glass if block ~ ~-2 ~ glowstone if block ~ ~-3 ~ dried_kelp_block run function gun:selectors/burst
schedule function gun:selectors/loop 1t