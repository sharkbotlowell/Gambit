tag @s add Red
say I Joined the Red Team!
tag @s remove Blue