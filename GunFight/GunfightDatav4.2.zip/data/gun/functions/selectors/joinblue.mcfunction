tag @s remove Red
tag @s add Blue
say I joined the Blue Team!