team remove red
team remove blue
team remove lobby