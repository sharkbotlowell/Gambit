schedule clear nonametags:20t
team remove nonametags
tellraw @a ["[No Player Name Tags] Please delete the datapack or mod now."]
datapack disable "file/No Player Name Tags V4"
datapack disable "file/No Player Name Tags V4.zip"